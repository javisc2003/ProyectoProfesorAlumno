package com.example.actividad;

public enum TipoPractica {
    DUAL,FCT
}
